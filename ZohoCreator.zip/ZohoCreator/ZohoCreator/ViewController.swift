//
//  ViewController.swift
//  ZohoCreator
//
//  Created by sene sreenu on 13/12/16.
//  Copyright © 2016 Hydoodle Techonologies PVT LTD. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var nameValue: UITextField!
    @IBOutlet var idValue: UITextField!
    @IBOutlet var submitButton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func sendButton(sender: AnyObject) {
     
        let name:String = nameValue.text!
        let id: String =  idValue.text!
        let postEndpoint: String = "https://creator.zoho.com/api/dhivysh/json/sample-application/form/Sample/record/add/"
        let url = NSURL(string: postEndpoint)!
        let request: NSMutableURLRequest =  NSMutableURLRequest(URL: url)
        request.HTTPMethod = "POST"
        let bodyData = "authtoken=1d2c5bf71792f844c6067e0665403be3&scope=creatorapi&Name=\(name)&Table_Number=\(id)"
        request.HTTPBody = bodyData.dataUsingEncoding(NSUTF8StringEncoding);
        NSURLConnection.sendAsynchronousRequest(request, queue: NSOperationQueue.mainQueue())
            {
                (response, data, error) in
                print(NSString(data: data!, encoding: NSUTF8StringEncoding))
                let data2: NSString = NSString(data: data!, encoding: NSUTF8StringEncoding)!
                let stringResponse = data2 as String
                if stringResponse.rangeOfString("Success") != nil {
                    let alert = UIAlertController(title: "Success!", message: "Data inserted Successfully", preferredStyle: UIAlertControllerStyle.Alert)
                    alert.addAction(UIAlertAction(title: "Close", style: UIAlertActionStyle.Default, handler: nil))
                    self.presentViewController(alert, animated: true, completion: nil)
                }
                else
                {
                    let alert = UIAlertController(title: "Failed", message: "Failed to insert data", preferredStyle: UIAlertControllerStyle.Alert)
                    alert.addAction(UIAlertAction(title:"Close", style: UIAlertActionStyle.Default, handler: nil))
                    self.presentViewController(alert,animated: true, completion: nil)
                    
                }
        }    }

}

