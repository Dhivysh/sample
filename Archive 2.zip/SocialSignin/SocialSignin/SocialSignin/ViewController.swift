//
//  ViewController.swift
//  SocialSignin
//
//  Created by sene sreenu on 28/11/16.
//  Copyright © 2016 Hydoodle Techonologies PVT LTD. All rights reserved.
//

import UIKit
import Fabric
import TwitterKit
class ViewController: UIViewController, GIDSignInUIDelegate {

   
    @IBAction func logoutButon(sender: UIButton) {
        GIDSignIn.sharedInstance().signOut()
        
    }
    @IBAction func didTapSignOut(sender: AnyObject) {
        GIDSignIn.sharedInstance().signOut()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        let logInButton = TWTRLogInButton { (session, error) in
            if let unwrappedSession = session {
                let alert = UIAlertController(title: "Logged In",
                    message: "User \(unwrappedSession.userName) has logged in",
                    preferredStyle: UIAlertControllerStyle.Alert
                )
                let cancelAction = UIAlertAction(title: "Logout", style: UIAlertActionStyle.Default) {
                    UIAlertAction in
                        Twitter.sharedInstance().sessionStore.logOutUserID(unwrappedSession.userID)
                }
                alert.addAction(cancelAction)
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: nil))
                self.presentViewController(alert, animated: true, completion: nil)
            } else {
                NSLog("Login error: %@", error!.localizedDescription);
            }
        }
        
        // TODO: Change where the log in button is positioned in your view
        GIDSignIn.sharedInstance().uiDelegate = self
        logInButton.center = self.view.center
        self.view.addSubview(logInButton)


    }




}

