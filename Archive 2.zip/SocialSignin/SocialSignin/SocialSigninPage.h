//
//  SocialSigninPage.h
//  SocialSignin
//
//  Created by sene sreenu on 28/11/16.
//  Copyright © 2016 Hydoodle Techonologies PVT LTD. All rights reserved.
//

#ifndef SocialSigninPage_h
#define SocialSigninPage_h


#endif /* SocialSigninPage_h */
