//
//  ViewController.swift
//  TouchID
//
//  Created by sene sreenu on 30/11/16.
//  Copyright © 2016 Hydoodle Techonologies PVT LTD. All rights reserved.
//

import UIKit
import LocalAuthentication
class ViewController: UIViewController {

    @IBAction func loginButton(sender: AnyObject) {
        let authenticationContext = LAContext()
        var error:NSErrorPointer
        error = nil
        guard    authenticationContext.canEvaluatePolicy(.DeviceOwnerAuthenticationWithBiometrics, error: error) else {
            
            let alertController = UIAlertController(title: "TouchID", message: "Device does not have a biometricsensor", preferredStyle: UIAlertControllerStyle.Alert)
            let action = UIAlertAction(title: "Dismiss", style: UIAlertActionStyle.Default, handler: nil)
            alertController.addAction(action)
            self.presentViewController(alertController, animated: true, completion: nil)
            return
        }
        authenticationContext.evaluatePolicy(.DeviceOwnerAuthenticationWithBiometrics, localizedReason: "Scan to Login", reply: {[unowned self] (success, error) -> Void in
            if(success){
                let alertController = UIAlertController(title:"TouchID",message:"Accepted",preferredStyle: UIAlertControllerStyle.Alert)
                let action = UIAlertAction(title:"Dismiss",style: UIAlertActionStyle.Default,handler:nil)
                alertController.addAction(action)
                self.presentViewController(alertController,animated:true,completion:nil)

            }
            else{
                let alertController = UIAlertController(title:"TouchID",message:"Failed",preferredStyle: UIAlertControllerStyle.Alert)
                let action = UIAlertAction(title:"Dismiss",style: UIAlertActionStyle.Default,handler:nil)
                alertController.addAction(action)
                self.presentViewController(alertController,animated:true,completion:nil)
            }

            })
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

