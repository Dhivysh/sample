//
//  ViewController.swift
//  DropBoxSample
//
//  Created by sene sreenu on 05/12/16.
//  Copyright © 2016 Hydoodle Techonologies PVT LTD. All rights reserved.
//

import UIKit

class ViewController: UIViewController, DBRestClientDelegate, UITableViewDelegate{

    var  dbRestClient: DBRestClient!
    func restClient(client: DBRestClient!, uploadedFile destPath: String!, from srcPath: String!, metadata: DBMetadata!) {
        print("The file has been uploaded.")
        print(metadata.path)
    }
    func restClient(client: DBRestClient!, uploadFileFailedWithError error: NSError!) {
        print("File upload failed.")
        print(error.description)
    }
    func handleDidLinkNotification(notification: NSNotification) {
        initDropboxRestClient()
    }
    @IBAction func connectToDB(sender: AnyObject) {
        if !DBSession.sharedSession().isLinked(){
            DBSession.sharedSession().linkFromController(self)
        }
        else {
            DBSession.sharedSession().unlinkAll()
        }

    }
    func initDropboxRestClient() {
        dbRestClient   = DBRestClient(session: DBSession.sharedSession())
        dbRestClient.delegate = self
    }
    @IBAction func connecttoDropbox(sender: AnyObject){
        if !DBSession.sharedSession().isLinked(){
            DBSession.sharedSession().linkFromController(self)
        }
        else {
            DBSession.sharedSession().unlinkAll()
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        NSNotificationCenter.defaultCenter().addObserver(self, selector: "handleDidLinkNotification:", name: "didLinkToDropboxAccountNotification", object: nil)
        if DBSession.sharedSession().isLinked() {
            initDropboxRestClient()
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
    @IBAction func performAction(sender: AnyObject) {
        if !DBSession.sharedSession().isLinked(){
            print("Not connected to Dropbox")
        }
        let actionSheet = UIAlertController(title: "Upload file", message: "Select file to upload", preferredStyle: UIAlertControllerStyle.ActionSheet)
        let uploadTextFileAction = UIAlertAction(title: "Upload text file", style: UIAlertActionStyle.Default) { (action) -> Void in
            let uploadFilename = "testtext.txt"
            let sourcePath = NSBundle.mainBundle().pathForResource("testtext", ofType: "txt")
            let destinationPath = "/"
            self.dbRestClient.uploadFile(uploadFilename, toPath: destinationPath, withParentRev: nil, fromPath: sourcePath)
        }
        let uploadImageFileAction = UIAlertAction(title: "Upload image", style: UIAlertActionStyle.Default) { (action) -> Void in
            let uploadFilename = "nature.jpg"
            let sourcePath = NSBundle.mainBundle().pathForResource("nature", ofType: "jpg")
            let destinationPath = "/"
            self.dbRestClient.uploadFile(uploadFilename, toPath: destinationPath, withParentRev: nil, fromPath: sourcePath)
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertActionStyle.Cancel) { (action) -> Void in
        }
        actionSheet.addAction(uploadTextFileAction)
        actionSheet.addAction(uploadImageFileAction)
        actionSheet.addAction(cancelAction)
        presentViewController(actionSheet, animated: true, completion: nil)
        
    }

}

